-- Product views in out-of-stock products
SELECT
    extract(day from derived_tstamp) as Date,
    COUNT(DISTINCT event_id) as number_views
FROM
    `$1`.`$2`.snowplow_ecommerce_product_interactions
WHERE
    is_product_view
    AND product_inventory_status = 'out_of_stock'
group by 1
